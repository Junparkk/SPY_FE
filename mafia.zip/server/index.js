// dd
const express = require('express');
const app = express();
const http = require('http');
const cors = require('cors');
const { Server } = require('socket.io');
const { disconnect } = require('process');

app.use(cors());

// var fs = require('fs');
// var options = {
//   key: fs.readFileSync('openvidukey.pem'),
//   cert: fs.readFileSync('openviducert.pem'),
//   secure: true,
//   reconnect: true,
//   rejectUnauthorized: false,
// };
const server = http.createServer(app)

const io = new Server(server, {
  cors: {
    origin: 'http://localhost:3000',
    methods: ['GET', 'POST'],
  },
});

io.on('connection', (socket) => {
  socket['nickname'] = `Anon`;

  socket.on('join_room', (data, nickname) => {
    socket.join(data);
    socket.nickname = `${nickname}`;
    // socket.emit('join_room', `roomId : ${data}`, `nickname: ${socket.nickname}`, socket.id)
    socket.to(data).emit('join_room', `${data}`, `${socket.nickname}`, socket.id)
    console.log(`유저아이디 : ${socket.nickname} 방이름 : ${data}`, socket.id);
  });
  socket.on('send_message', (data) => {
    socket.to(data.room).emit('receive_message', data);
  });

  socket.on('private message', (data) => {
    socket.to(data.room).to(socket.id).emit('private message', data);
  });

  socket.on('disconnect', () => {
    console.log('User Disconnected', socket.id);
  });
});

server.listen(3001, () => {
  console.log('서버가 시작됐어요!');
});
