#!/bin/bash

docker build --pull --no-cache --rm=true -t openvidu/openvidu-demo-proxy .