import React, { useState } from 'react';
import Slider from '../components/Slider/Slider';

//앙 허전해~ 
const Tutorial = () => {
  return (
    <>
      <Slider/>
    </>
  );
};

export default Tutorial;
